"""
Kernel and Mesa Updater UI Components

This package provides UI components for the kernel and Mesa updater.
"""
