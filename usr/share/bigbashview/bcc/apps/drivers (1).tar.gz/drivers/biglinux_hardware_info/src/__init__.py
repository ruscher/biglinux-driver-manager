"""
Source module for biglinux_hardware_info package.
"""
