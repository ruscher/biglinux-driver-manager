"""
UI components for the BigLinux Hardware Info package.
"""
