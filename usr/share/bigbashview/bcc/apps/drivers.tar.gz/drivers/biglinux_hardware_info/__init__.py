"""
BigLinux Hardware Information Package

This package provides hardware information functionality for the BigLinux Driver Manager.
"""
