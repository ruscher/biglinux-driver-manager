import gi
from typing import Dict, List, Any, Optional, Tuple
import logging
import json
import subprocess
import threading
import re # Já estava presente, mas reforçando o uso
import os
import tempfile

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib, Pango

# Stub classes (como no original)
try:
    from .src.system_info import SystemInfo
    from .src.ui.custom_widgets import CategoryRow
except ImportError:
    logger_stub = logging.getLogger(__name__ + "_stub") # Use different name to avoid conflict if main logger is set up
    logger_stub.warning("Could not import SystemInfo or CategoryRow. Using stubs.")
    class SystemInfo: 
        def __init__(self):
            pass
    class CategoryRow(Gtk.ListBoxRow):
        def __init__(self, category_id: str, title: str, icon_name: str):
            super().__init__()
            self.category_id = category_id
            self.set_name(f"category-row-{category_id.lower().replace(' ', '-')}")
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            box.set_margin_top(6); box.set_margin_bottom(6); box.set_margin_start(6); box.set_margin_end(6)
            if icon_name:
                icon = Gtk.Image.new_from_icon_name(icon_name)
                box.append(icon)
            label = Gtk.Label(label=title); label.set_xalign(0)
            box.append(label)
            self.set_child(box)

logger = logging.getLogger(__name__)
if not logger.hasHandlers():
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


class HardwareInfoPage(Gtk.Box):
    """
    Hardware Information page component.
    This page displays hardware information in both summary and detailed views.
    """
    
    def __init__(self) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.system_info = SystemInfo()
        self.hardware_data: Dict[str, Any] = {} 
        self.raw_inxi_data: Dict[str, List[Dict[str, Any]]] = {} # Changed to Dict of Lists
        self.pulse_id: int = 0 
        self._create_ui()
        self._load_hardware_info()
    
    def _create_ui(self) -> None:
        # ... (UI creation code remains largely the same as your previous version) ...
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        header_box.set_margin_top(12); header_box.set_margin_bottom(12); header_box.set_margin_start(12); header_box.set_margin_end(12)
        title_label = Gtk.Label(); title_label.set_markup("<b>System Overview</b>"); title_label.set_hexpand(True)
        title_label.set_halign(Gtk.Align.START); title_label.add_css_class("title-4"); header_box.append(title_label)
        refresh_button = Gtk.Button(); refresh_button.set_icon_name("view-refresh-symbolic")
        refresh_button.set_tooltip_text("Refresh information"); refresh_button.connect("clicked", self._on_refresh_clicked)
        header_box.append(refresh_button); self.append(header_box)
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL); self.append(separator)
        self.progress_bar = Gtk.ProgressBar(); self.progress_bar.set_halign(Gtk.Align.CENTER); self.progress_bar.set_valign(Gtk.Align.CENTER)
        self.progress_bar.set_vexpand(True); self.progress_bar.set_pulse_step(0.1); self.progress_bar.set_show_text(False)
        self.progress_bar.set_tooltip_text("Loading hardware information..."); self.append(self.progress_bar)
        self.split_view = Adw.NavigationSplitView(); self.split_view.set_vexpand(True); self.split_view.set_sidebar_width_fraction(0.3)
        self.split_view.set_min_sidebar_width(280); self.split_view.set_max_sidebar_width(450); self.split_view.set_visible(False)
        sidebar = Adw.NavigationPage.new(Gtk.Box(), "Hardware Categories")
        sidebar_scroll = Gtk.ScrolledWindow(); sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.category_list = Gtk.ListBox(); self.category_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.category_list.set_css_classes(["navigation-sidebar"]); self.category_list.connect("row-selected", self._on_category_selected)
        sidebar_scroll.set_child(self.category_list); sidebar.set_child(sidebar_scroll)
        self.content_view = Adw.NavigationPage.new(Gtk.Box(), "Details")
        self.content_scroll = Gtk.ScrolledWindow(); self.content_scroll.set_vexpand(True)
        self.content_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL); self.content_box.set_margin_top(12)
        self.content_box.set_margin_bottom(12); self.content_box.set_margin_start(18); self.content_box.set_margin_end(18)
        self.content_box.set_spacing(12); self.content_scroll.set_child(self.content_box); self.content_view.set_child(self.content_scroll)
        self.split_view.set_sidebar(sidebar); self.split_view.set_content(self.content_view); self.append(self.split_view)

    def _pulse_progress_bar(self) -> bool:
        if self.progress_bar.get_visible():
            self.progress_bar.pulse()
            return True  
        self.pulse_id = 0
        return False 

    def _load_hardware_info(self) -> None:
        self.progress_bar.set_visible(True)
        self.progress_bar.set_fraction(0.0) 
        if hasattr(self, 'error_box_container') and self.error_box_container.get_parent():
            self.remove(self.error_box_container)
        if self.pulse_id == 0: 
            self.pulse_id = GLib.timeout_add(150, self._pulse_progress_bar) 
        self.split_view.set_visible(False)
        thread = threading.Thread(target=self._fetch_inxi_data)
        thread.daemon = True
        thread.start()

    def _parse_size_string_to_bytes(self, size_str: Optional[str]) -> Optional[float]:
        if not isinstance(size_str, str):
            return None
        
        # Handle cases like "16MiB" or "16 MiB" or "16MiB"
        size_str_cleaned = size_str.replace(" ", "") 
        match = re.match(r"([\d.]+)([KMGTPEZY]I?B)", size_str_cleaned, re.IGNORECASE)
        if not match:
            # Try matching if there was a space originally, e.g. "16 GiB"
            match = re.match(r"([\d.]+)\s*([KMGTPEZY]I?B)", size_str, re.IGNORECASE)
            if not match:
                 return None
        
        val_str, unit_str = match.groups()
        try:
            value = float(val_str)
        except ValueError:
            return None

        unit = unit_str.upper()
        power = 1
        if unit.startswith("K"): power = 1024
        elif unit.startswith("M"): power = 1024**2
        elif unit.startswith("G"): power = 1024**3
        elif unit.startswith("T"): power = 1024**4
        return value * power

    def _add_usage_bar_row(self, group: Adw.PreferencesGroup, title: str,
                           used_bytes: Optional[float], total_bytes: Optional[float],
                           label_override: Optional[str] = None,
                           icon_name: Optional[str] = None) -> None:
        row = Adw.ActionRow()
        row.set_title(title)
        
        if icon_name:
            icon_widget = Gtk.Image.new_from_icon_name(icon_name)
            row.add_prefix(icon_widget)

        progress_bar_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_hexpand(True)
        progress_bar.set_css_classes(["thin"]) 
        progress_bar_box.append(progress_bar)
        
        # Add a label for percentage next to the bar if not showing text on bar
        # percentage_label = Gtk.Label()
        # percentage_label.set_width_chars(5) # "100%"
        # progress_bar_box.append(percentage_label)

        row.add_suffix(progress_bar_box) 

        if used_bytes is not None and total_bytes is not None and total_bytes > 0:
            percentage = (used_bytes / total_bytes) * 100
            fraction = min(1.0, max(0.0, used_bytes / total_bytes)) # Ensure fraction is between 0 and 1

            if label_override:
                subtitle_text = label_override
            else:
                used_str = GLib.format_size(int(used_bytes))
                total_str = GLib.format_size(int(total_bytes))
                subtitle_text = f"{used_str} de {total_str} ({percentage:.1f}%)"
            
            row.set_subtitle(subtitle_text)
            progress_bar.set_fraction(fraction)
            progress_bar.set_text(f"{percentage:.0f}%") 
            progress_bar.set_show_text(True)
            # percentage_label.set_text(f"{percentage:.0f}%")
        else:
            row.set_subtitle("Informação indisponível")
            progress_bar.set_fraction(0)
            progress_bar.set_text("N/A")
            progress_bar.set_show_text(True)
            # percentage_label.set_text("N/A")
            progress_bar.set_sensitive(False)
            
        row.set_subtitle_selectable(True)
        group.add(row)

    def _create_system_summary(self) -> None:
        """Create a system summary card based on the new requirements."""
        # Clear previous content_box items if any (e.g. from a previous error or view)
        # This is usually handled in _display_category_details, but good for standalone refresh too.
        while child := self.content_box.get_first_child():
            self.content_box.remove(child)

        # --- Hardware Group ---
        hardware_group = Adw.PreferencesGroup()
        hardware_group.set_title("Hardware")
        # hardware_group.set_description("Componentes principais do sistema") # Optional
        
        # Processor
        cpu_model_str = "Desconhecido"
        cpu_section = self.raw_inxi_data.get("CPU")
        if cpu_section and isinstance(cpu_section, list) and len(cpu_section) > 0:
            # First item in CPU list usually has 'model'
            # Second item has 'cores', 'threads'
            model = cpu_section[0].get("model", "CPU Desconhecido")
            cores = "N/A"
            if len(cpu_section) > 1 and isinstance(cpu_section[1], dict):
                cores = cpu_section[1].get("cores", "N/A")
            cpu_model_str = f"{model} ({cores} cores)"
        self._add_summary_row(hardware_group, "Processor", cpu_model_str, "cpu-symbolic")

        # Total Memory (with usage bar)
        total_mem_bytes, used_mem_bytes = None, None
        mem_label_override = None

        # Priority 1: Dedicated "Memory" section (if inxi -m provides it clearly)
        memory_section_dedicated = self.raw_inxi_data.get("Memory")
        if memory_section_dedicated and isinstance(memory_section_dedicated, list):
            ram_info_list = [item.get("ram") for item in memory_section_dedicated if isinstance(item, dict) and "ram" in item]
            if ram_info_list and isinstance(ram_info_list[0], dict):
                ram_info = ram_info_list[0]
                total_obj = ram_info.get('total')
                used_obj = ram_info.get('used')
                if isinstance(total_obj, dict):
                    total_mem_bytes = self._parse_size_string_to_bytes(f"{total_obj.get('value')} {total_obj.get('unit')}")
                elif isinstance(total_obj, str):
                     total_mem_bytes = self._parse_size_string_to_bytes(total_obj)
                if isinstance(used_obj, dict):
                    used_mem_bytes = self._parse_size_string_to_bytes(f"{used_obj.get('value')} {used_obj.get('unit')}")
                elif isinstance(used_obj, str):
                    used_mem_bytes = self._parse_size_string_to_bytes(used_obj)
        
        # Priority 2: "Info" section (fallback based on provided JSON)
        if total_mem_bytes is None or used_mem_bytes is None:
            info_section = self.raw_inxi_data.get("Info")
            if info_section and isinstance(info_section, list):
                memory_item_in_info = next((item for item in info_section if isinstance(item, dict) and item.get("Memory") == ""), None)
                if memory_item_in_info:
                    # Example: "total": "48 GiB", "used": "14.08 GiB (30.3%)", "available": "46.42 GiB"
                    total_mem_str = memory_item_in_info.get("total") # e.g., "48 GiB"
                    used_mem_str_full = memory_item_in_info.get("used") # e.g., "14.08 GiB (30.3%)"
                    
                    total_mem_bytes = self._parse_size_string_to_bytes(total_mem_str)
                    if used_mem_str_full:
                        used_match = re.match(r"([\d.]+\s*[KMGTPEZY]i?B?)", used_mem_str_full)
                        if used_match:
                            used_mem_bytes = self._parse_size_string_to_bytes(used_match.group(1))
                            # mem_label_override = used_mem_str_full # Use the full string from inxi as it's already well formatted

        self._add_usage_bar_row(hardware_group, "Total Memory", 
                                used_mem_bytes, total_mem_bytes,
                                label_override=mem_label_override,
                                icon_name="memory-symbolic")

        # Graphics
        graphics_str = "Desconhecido"
        graphics_section = self.raw_inxi_data.get("Graphics")
        if graphics_section and isinstance(graphics_section, list):
            for device_info in graphics_section:
                if isinstance(device_info, dict) and device_info.get("class-ID") == "0300" and "Device" in device_info:
                    vendor = device_info.get("vendor", "")
                    model_name = device_info.get("Device", "GPU Desconhecido") 
                    # Remove vendor prefix from model_name if present, e.g., "NVIDIA GP104 [GeForce GTX 1070]" -> "GP104 [GeForce GTX 1070]"
                    model_name_cleaned = re.sub(r"^(Advanced Micro Devices \[AMD/ATI\]|NVIDIA|Intel Corporation)\s*", "", model_name).strip()
                    graphics_str = f"{vendor} {model_name_cleaned}".strip()
                    break 
        self._add_summary_row(hardware_group, "Graphics", graphics_str, "video-display-symbolic")
        
        self.content_box.append(hardware_group)

        # --- OS Information Group ---
        os_group = Adw.PreferencesGroup()
        os_group.set_title("OS Information")
        # os_group.set_description("Detalhes do sistema operacional e armazenamento")

        # Armazenamento do sistema (Disk Usage Bar & Details)
        storage_summary = self._get_storage_summary() # Expects Dict[str, Any] with byte values and strings

        if storage_summary.get('partition_total_bytes') is not None and \
           storage_summary.get('partition_used_bytes') is not None:
            
            disk_label_override = (f"{storage_summary.get('partition_used_str', 'N/A')} de "
                                   f"{storage_summary.get('partition_total_str', 'N/A')} em "
                                   f"{storage_summary.get('partition_device', 'N/A')} ({storage_summary.get('partition_usage_percent', 'N/A')})")

            self._add_usage_bar_row(os_group, "Uso do Disco (/) ", # Title for the bar itself
                                    storage_summary['partition_used_bytes'],
                                    storage_summary['partition_total_bytes'],
                                    label_override=disk_label_override,
                                    icon_name="drive-harddisk-symbolic")
            
            self._add_summary_row(os_group, "Instalado na partição", storage_summary.get('partition_device', 'N/A'), "drive-harddisk-root-symbolic") # New icon
            self._add_summary_row(os_group, "Tamanho da partição", storage_summary.get('partition_total_str', 'N/A'), "view-fullscreen-symbolic") # New icon
            self._add_summary_row(os_group, "Espaço utilizado", storage_summary.get('partition_used_str', 'N/A'), "folder-download-symbolic") # Changed icon
            self._add_summary_row(os_group, "Espaço livre", storage_summary.get('partition_free_str', 'N/A'), "folder-open-symbolic")

        else: # Fallback if detailed byte info couldn't be parsed
            self._add_summary_row(os_group, "Armazenamento", "Informação indisponível", "drive-harddisk-symbolic")


        # Operating System
        os_name_str = "Desconhecido"
        system_section = self.raw_inxi_data.get("System")
        if system_section and isinstance(system_section, list):
            for item in system_section:
                if isinstance(item, dict) and "Distro" in item:
                    os_name_str = item.get("Distro", "Desconhecido")
                    break
        self._add_summary_row(os_group, "Operating System", os_name_str, "computer-symbolic")

        # Kernel Version
        kernel_ver_str = "Desconhecido"
        if system_section and isinstance(system_section, list): # system_section already fetched
            for item in system_section:
                if isinstance(item, dict) and "Kernel" in item:
                    kernel_ver_str = item.get("Kernel", "Desconhecido")
                    break
        self._add_summary_row(os_group, "Kernel Version", kernel_ver_str, "preferences-system-symbolic")
        
        # Data da instalação
        install_date = self._get_installation_date()
        self._add_summary_row(os_group, "Data da instalação", install_date or "Não determinada", "calendar-symbolic")
        
        self.content_box.append(os_group)

        # Handle case where no information was found for any group
        if not hardware_group.get_first_child() and not os_group.get_first_child():
            label = Gtk.Label(label="System information could not be retrieved.")
            label.set_halign(Gtk.Align.CENTER); label.set_valign(Gtk.Align.CENTER); label.set_vexpand(True)
            self.content_box.append(label)


    def _get_storage_summary(self) -> Dict[str, Any]:
        """Extract storage summary for root, including byte values for calculations."""
        storage_info: Dict[str, Any] = {}
        partition_section = self.raw_inxi_data.get("Partition")
        
        root_part_data = None
        if partition_section and isinstance(partition_section, list):
            for part_data_item in partition_section:
                if isinstance(part_data_item, dict) and part_data_item.get("ID") == "/":
                    root_part_data = part_data_item
                    break
        
        if root_part_data:
            storage_info['partition_device'] = root_part_data.get("dev", "N/A")
            
            total_str_inxi = root_part_data.get("raw-size") # e.g., "931.22 GiB"
            used_str_full_inxi = root_part_data.get("used") # e.g., "870.73 GiB (93.5%)"

            total_bytes = self._parse_size_string_to_bytes(total_str_inxi)
            used_bytes = None
            used_str_for_display = "N/A"
            
            if used_str_full_inxi:
                match = re.match(r"([\d.]+\s*[KMGTPEZY]i?B?)\s*\(?([\d.]+%)?\)?", used_str_full_inxi)
                if match:
                    used_val_unit_part = match.group(1)
                    used_bytes = self._parse_size_string_to_bytes(used_val_unit_part)
                    used_str_for_display = used_val_unit_part # For display
                    if match.group(2): # Percentage part
                         storage_info['partition_usage_percent'] = match.group(2)
            
            if total_bytes is not None:
                storage_info['partition_total_bytes'] = total_bytes
                storage_info['partition_total_str'] = GLib.format_size(int(total_bytes))
            if used_bytes is not None:
                storage_info['partition_used_bytes'] = used_bytes
                storage_info['partition_used_str'] = GLib.format_size(int(used_bytes)) # Format for consistency
            
            if total_bytes is not None and used_bytes is not None:
                free_bytes = total_bytes - used_bytes
                storage_info['partition_free_bytes'] = free_bytes
                storage_info['partition_free_str'] = GLib.format_size(int(free_bytes))
                if 'partition_usage_percent' not in storage_info and total_bytes > 0: # Calculate if not parsed
                    storage_info['partition_usage_percent'] = f"{(used_bytes / total_bytes * 100):.1f}%"
            
        # If inxi data was incomplete, try df fallback
        if not all(k in storage_info for k in ['partition_total_bytes', 'partition_used_bytes', 'partition_free_bytes']):
            logger.debug("Inxi storage data incomplete for root, trying df fallback.")
            df_fallback_info = self._get_storage_fallback()
            # Merge df_fallback_info, giving preference to already parsed inxi fields if they exist
            for key, value in df_fallback_info.items():
                if key not in storage_info or storage_info[key] is None:
                    storage_info[key] = value
        return storage_info

    def _get_storage_fallback(self) -> Dict[str, Any]:
        storage_info_fallback: Dict[str, Any] = {}
        try:
            df_output = subprocess.check_output(
                ['df', '--output=source,size,used,avail', '--block-size=1', '/'], 
                text=True, timeout=5
            )
            lines = df_output.strip().split('\n')
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 4:
                    storage_info_fallback['partition_device'] = parts[0]
                    try:
                        total_b = float(parts[1])
                        used_b = float(parts[2])
                        avail_b = float(parts[3]) # df provides available directly
                        
                        storage_info_fallback['partition_total_bytes'] = total_b
                        storage_info_fallback['partition_used_bytes'] = used_b
                        storage_info_fallback['partition_free_bytes'] = avail_b # Use df's 'avail'

                        storage_info_fallback['partition_total_str'] = GLib.format_size(int(total_b))
                        storage_info_fallback['partition_used_str'] = GLib.format_size(int(used_b))
                        storage_info_fallback['partition_free_str'] = GLib.format_size(int(avail_b))
                        
                        if total_b > 0:
                            storage_info_fallback['partition_usage_percent'] = f"{(used_b / total_b * 100):.1f}%"
                    except ValueError:
                        logger.debug("Could not parse df numeric output during fallback.")
        except Exception as e:
            logger.debug(f"Failed to get storage info from df fallback: {e}")
        return storage_info_fallback

    def _get_installation_date(self) -> Optional[str]:
        # ... (implementation from your previous version is fine) ...
        try:
            df_output = subprocess.check_output(['df', '/'], text=True, timeout=2).strip().split('\n')
            if len(df_output) > 1:
                root_device_path = df_output[1].split()[0]
                # Check stat of root dir itself or device, st_ctime can be an approximation
                # For ext filesystems, tune2fs is more accurate but requires root and device path.
                # Let's use stat on '/' as a general approach for ctime.
                stat_info = os.stat('/')
                install_timestamp = stat_info.st_ctime # inode change time
                install_date = subprocess.check_output(
                    ['date', '-d', f'@{int(install_timestamp)}', '+%d/%m/%Y'],
                    text=True, timeout=2
                ).strip()
                return install_date
        except Exception as e:
            logger.debug(f"Could not determine installation date from root fs stat: {e}")
        # Fallback to lost+found
        try:
            if os.path.exists('/lost+found'):
                stat_info = os.stat('/lost+found')
                install_timestamp = stat_info.st_ctime
                install_date = subprocess.check_output(
                    ['date', '-d', f'@{int(install_timestamp)}', '+%d/%m/%Y'],
                    text=True, timeout=2
                ).strip()
                return install_date
        except Exception as e_lf:
            logger.debug(f"Could not determine installation date from /lost+found: {e_lf}")
        return None


    def _add_summary_row(self, group: Adw.PreferencesGroup, title: str, 
                        value: str, icon_name: Optional[str] = None) -> None: # Made icon_name optional
        row = Adw.ActionRow()
        row.set_title(title)
        row.set_subtitle(str(value) if value is not None else "N/A")
        row.set_subtitle_lines(3) # Allow more lines for potentially longer values
        row.set_subtitle_selectable(True)
        
        if icon_name:
            icon_widget = Gtk.Image.new_from_icon_name(icon_name)
            row.add_prefix(icon_widget)
        
        group.add(row)

    def _fetch_inxi_data(self) -> None:
        try:
            with tempfile.NamedTemporaryFile(delete=False, mode='w', suffix='.json', encoding='utf-8') as temp_file:
                temp_path = temp_file.name
            
            logger.debug(f"Writing inxi JSON data to temporary file: {temp_path}")
            # Using -Fxxxza ensures comprehensive data. Added -m (memory) and -P (partitions) for good measure.
            # --no-host -z for privacy/conciseness.
            inxi_cmd = ["inxi", "-FxxxzamP", "--output", "json", "--output-file", temp_path, "--no-host", "-z"]
            
            result = subprocess.run(inxi_cmd, capture_output=True, text=True, check=False, timeout=90)

            if result.returncode != 0:
                logger.error(f"inxi command finished with exit code {result.returncode}. Stderr: {result.stderr.strip()}")
                if not os.path.exists(temp_path) or os.path.getsize(temp_path) == 0:
                    raise subprocess.SubprocessError(
                        f"inxi failed (code {result.returncode}) and produced no/empty output file. Stderr: {result.stderr.strip()}"
                    )
                logger.warning("inxi returned non-zero but an output file was found. Attempting to process.")
            
            with open(temp_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Remove ANSI escape codes and # comments from JSON values (if any remain after --output json)
            content = re.sub(r'\x1b\[[0-9;]*m', '', content) 
            content = re.sub(r'"[^"]*#([^"]*)"', r'"\1"', content) # More robustly handles comments within strings
            
            try:
                raw_data_list_from_json = json.loads(content)
                
                # Transform the list of single-key dicts into one dict for easier access
                transformed_data: Dict[str, List[Dict[str, Any]]] = {}
                if isinstance(raw_data_list_from_json, list):
                    for item_dict_wrapper in raw_data_list_from_json:
                        if isinstance(item_dict_wrapper, dict):
                            transformed_data.update(item_dict_wrapper)
                
                self.raw_inxi_data = transformed_data 
                # self._log_data_structure(self.raw_inxi_data, max_level=1, current_path="raw_inxi_data_transformed")

                # For detailed views, self.hardware_data can be processed further if needed,
                # but for now, let's use the transformed structure for both.
                # The _update_ui_with_data method will create display categories from this.
                self.hardware_data = self._map_raw_to_display_categories(self.raw_inxi_data)
                
            except json.JSONDecodeError as json_err:
                # ... (error handling for JSONDecodeError as in your previous version) ...
                error_position = json_err.pos; context_start = max(0, error_position - 30)
                context_end = min(len(content), error_position + 30); context_snippet = content[context_start:context_end]
                logger.error(f"JSON parsing error: {json_err.msg} at pos {error_position}. Context: ...'{context_snippet}'...")
                problem_file_path = os.path.join(tempfile.gettempdir(), "inxi_problematic.json")
                with open(problem_file_path, "w", encoding='utf-8') as pf: pf.write(content)
                logger.error(f"Problematic JSON content saved to {problem_file_path}")
                raise 
            
            GLib.idle_add(self._update_ui_with_data)
            
        except (subprocess.SubprocessError, subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError, IOError) as e:
            logger.error(f"Error fetching or processing hardware info: {e}", exc_info=True)
            GLib.idle_add(self._show_error_message, f"Erro ao buscar informações de hardware: {str(e)}")
        finally:
            if 'temp_path' in locals() and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                    logger.debug(f"Temporary file {temp_path} deleted.")
                except Exception as e_unlink:
                    logger.warning(f"Failed to delete temporary file {temp_path}: {e_unlink}")

    def _map_raw_to_display_categories(self, raw_data: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
        """Maps raw inxi sections to display category names and their data."""
        # This mapping is primarily for the sidebar categories and the detailed view.
        # The System Summary view uses self.raw_inxi_data directly.
        category_mapping_keys = { 
            # Inxi Key (exact from JSON) : Display Name
            "System": "System Information", "CPU": "Processor (CPU)", "Graphics": "Graphics / GPU",
            "Audio": "Audio Devices", "Network": "Network Interfaces", "Drives": "Storage Devices",
            "Partition": "Partitions", "Usb": "USB Devices", "Sensors": "Sensors", # Usb from inxi is often capitalized
            "Memory": "Memory Details", 
            "Machine": "Machine Info", "Info": "Processes & System Load",
            "Battery": "Battery Status", "RAID": "RAID Arrays", # RAID can be "RAID Devices"
            "Bluetooth": "Bluetooth Devices", "Repos": "Software Repositories",
            # Keys that might be nested but sometimes appear top-level or are useful:
            # The actual keys from inxi JSON (like 'System', 'CPU') are used here.
        }
        
        processed_data = {}
        for raw_key, raw_value_list in raw_data.items():
            display_name = category_mapping_keys.get(raw_key, raw_key.replace('_', ' ').title())
            # For detailed view, we might want to pass the list of dicts directly,
            # or further process/flatten it if that makes display easier.
            # For now, let's pass the list of dicts associated with the raw_key.
            processed_data[display_name] = raw_value_list 
        return processed_data


    def _log_data_structure(self, data: Any, level: int = 0, max_level: int = 2, current_path: str = "") -> None:
        # ... (implementation from your previous version is fine) ...
        indent = '  ' * level
        if level > max_level:
            logger.debug(f"{indent}{current_path}: [Nesting level too deep, truncating...]")
            return
        
        if isinstance(data, dict):
            logger.debug(f"{indent}{current_path or 'root'}: Dict with {len(data)} items:")
            if level < max_level:
                for key, value in data.items():
                    new_path = f"{current_path}.{key}" if current_path else key
                    value_type_name = type(value).__name__
                    value_preview = ""
                    if not isinstance(value, (dict, list)) or not value:
                        value_preview = str(value)[:50]; 
                        if len(str(value)) > 50: value_preview += "..."
                    logger.debug(f"{indent}  - Key: '{key}' (Type: {value_type_name}) {value_preview}")
                    if isinstance(value, (dict,list)) and value:
                        self._log_data_structure(value, level + 1, max_level, new_path)
        elif isinstance(data, list):
            logger.debug(f"{indent}{current_path or 'root'}: List with {len(data)} items:")
            if level < max_level and len(data) > 0:
                first_item_type = type(data[0]).__name__
                logger.debug(f"{indent}  - Items type (first): {first_item_type}")
                items_to_log = data[:min(2, len(data))] # Log first 2 items max
                for i, item in enumerate(items_to_log):
                    new_path = f"{current_path}[{i}]"
                    self._log_data_structure(item, level + 1, max_level, new_path)
                if len(data) > 2: logger.debug(f"{indent}  [... {len(data) - 2} more items ...]")
        else: logger.debug(f"{indent}{current_path}: Value: {str(data)[:100]}")

    def _update_ui_with_data(self) -> None:
        if self.pulse_id > 0:
            GLib.source_remove(self.pulse_id)
            self.pulse_id = 0
        self.progress_bar.set_fraction(1.0) 
        self.progress_bar.set_visible(False)
        self.split_view.set_visible(True)
        
        while child := self.category_list.get_first_child():
            self.category_list.remove(child)
        
        # self.hardware_data is now already mapped Dict[display_name, data_list]
        # by _map_raw_to_display_categories
        
        category_icon_mapping = {
            "System Summary": "document-properties-symbolic",
            "System Information": "computer-symbolic", "Processor (CPU)": "cpu-symbolic",
            "Memory Details": "memory-symbolic", "Graphics / GPU": "video-display-symbolic",
            "Audio Devices": "audio-card-symbolic", "Network Interfaces": "network-workgroup-symbolic",
            "Storage Devices": "drive-harddisk-symbolic", "Partitions": "drive-harddisk-system-symbolic",
            "USB Devices": "drive-removable-media-usb-symbolic", "Sensors": "sensors-fan-symbolic",
            "Machine Info": "computer-info-symbolic", "Processes & System Load": "utilities-system-monitor-symbolic",
            "Battery Status": "battery-symbolic", "RAID Arrays": "drive-multidisk-symbolic",
            "Bluetooth Devices": "bluetooth-active-symbolic", "Software Repositories": "folder-download-symbolic",
        } # Add more as needed based on actual display names from _map_raw_to_display_categories
        default_icon = "dialog-information-symbolic"
        
        category_order = {
            "System Summary": -10, "System Information": 0, "Processor (CPU)": 10, 
            "Memory Details": 20, "Graphics / GPU": 30, 
            "Storage Devices": 40, "Partitions": 45, "Network Interfaces": 50, 
            "Audio Devices": 60, "USB Devices": 70, "Bluetooth Devices": 75,
            "Machine Info": 80, "Battery Status": 90, "Sensors": 100, 
            "Processes & System Load": 110, "RAID Arrays": 120, "Software Repositories": 130,
        }
        
        all_display_categories_for_sidebar = {"System Summary": None} # Placeholder for data
        all_display_categories_for_sidebar.update(self.hardware_data) # self.hardware_data keys are display names

        sorted_categories = sorted(
            all_display_categories_for_sidebar.keys(),
            key=lambda x: (category_order.get(x, 1000), x) 
        )
        
        has_selected_row = False
        for category_display_name in sorted_categories:
            # Ensure data exists for this category in self.hardware_data, or it's "System Summary"
            if category_display_name == "System Summary" or self.hardware_data.get(category_display_name):
                icon_name = category_icon_mapping.get(category_display_name, default_icon)
                # Title for CategoryRow is already the display name
                row = CategoryRow(category_display_name, category_display_name, icon_name)
                self.category_list.append(row)
                if not has_selected_row: 
                    self.category_list.select_row(row)
                    has_selected_row = True
        
        if not has_selected_row and self.category_list.get_first_child():
             self.category_list.select_row(self.category_list.get_first_child())
        elif not self.category_list.get_first_child():
            self._show_error_message("No hardware categories could be displayed.")


    def _format_category_name(self, category: str) -> str:
        # This might not be needed as much if names are pre-formatted.
        return category # Names are now display names from mapping or .title()
    
    def _on_category_selected(self, listbox: Gtk.ListBox, row: Optional[Gtk.ListBoxRow]) -> None:
        if row is None or not isinstance(row, CategoryRow): 
            # ... (logging as before) ...
            return

        category_id_display_name = row.category_id # This is now the display name
        self.content_view.set_title(category_id_display_name) # Title is already formatted
        self._display_category_details(category_id_display_name)
    
    def _display_category_details(self, category_id_display_name: str) -> None:
        while child := self.content_box.get_first_child():
            self.content_box.remove(child)
        
        if category_id_display_name == "System Summary":
            self._create_system_summary() 
            return
        
        # Data for detailed view comes from self.hardware_data (mapped display names to data lists)
        category_data_list = self.hardware_data.get(category_id_display_name) 
        
        if not category_data_list: # category_data_list is a List of Dictionaries
            label = Gtk.Label(label=f"No information available for {category_id_display_name}.")
            label.set_halign(Gtk.Align.START); label.set_vexpand(True); label.set_valign(Gtk.Align.CENTER)
            self.content_box.append(label)
            return
        
        # The _process_category_data needs to handle a list of dicts as its top-level input for a category
        self._process_category_data(category_data_list, parent_key=category_id_display_name)


    def _process_category_data(self, data: Any, parent_key: str = "", level: int = 0) -> None:
        """
        Process and display category data recursively.
        'data' can be a list of dicts (for a whole category) or a single dict/list/value.
        'parent_key' is the title for the current data block.
        """
        if level > 7: # Increased max level slightly for complex inxi sections
            self._add_property_to_group(self._create_property_group(parent_key), "Data", "[Too deeply nested]")
            return

        if isinstance(data, list): # Handles the List[Dict] for a whole category, or nested lists
            if not data: return

            # If it's a list of dictionaries (common for inxi sections)
            if all(isinstance(item, dict) for item in data):
                # For the top-level list (level 0), parent_key is the category title.
                # We create a group for each dictionary in this list.
                list_items_group_title_prefix = parent_key # e.g., "CPU", "Graphics Device"
                
                for i, item_dict in enumerate(data):
                    # Try to find a sensible title for this specific item_dict from common keys
                    item_specific_title = item_dict.get('model', item_dict.get('Device', 
                                          item_dict.get('name', item_dict.get('IF', 
                                          item_dict.get('ID', "")))))
                    item_specific_title = str(item_specific_title).strip()

                    # Construct a title for the group representing this item_dict
                    # For level 0, parent_key is category name. For deeper, it's a sub-key.
                    current_item_group_display_title = f"{list_items_group_title_prefix} Item {i+1}"
                    if level == 0: # Main category, e.g. "Graphics" -> "Graphics Device 1"
                        singular_prefix = parent_key.removesuffix('s').removesuffix('es') if parent_key.endswith(('s', 'es')) else parent_key
                        current_item_group_display_title = f"{singular_prefix} {i+1}"

                    if item_specific_title:
                        current_item_group_display_title += f": {item_specific_title}"
                    
                    # Process this dictionary item. It will create its own group(s).
                    # Pass the constructed title.
                    self._process_category_data(item_dict, current_item_group_display_title, level + 1)
                return # Handled by recursive calls for each dict in list

            # Else, it's a list of simple items (strings, numbers) or mixed non-dict items
            # Create one group for the whole list.
            list_group = self._create_property_group(parent_key if parent_key else "Items")
            for i, item in enumerate(data):
                item_prefix = parent_key.removesuffix('s').removesuffix('es') if parent_key else "Item"
                row_title = f"{item_prefix} {i+1}"
                if isinstance(item, str):
                    self._add_property_to_group(list_group, row_title, item)
                elif isinstance(item, (dict, list)): # Should not happen often here, but stringify
                     self._add_property_to_group(list_group, row_title, json.dumps(item, indent=2))
                else: # Other simple types
                    self._add_property_to_group(list_group, row_title, str(item))
            if list_group.get_first_child(): self.content_box.append(list_group)

        elif isinstance(data, dict):
            # If data is a dict, it means it's either a sub-dictionary from a list item,
            # or a simple value that was wrapped in a dict by mistake (should not happen with inxi).
            # 'parent_key' here would be the title passed from the list processing step (e.g., "Graphics Device 1: NVIDIA ...")
            # or a key from a parent dictionary if we are deeper.

            group_for_dict = self._create_property_group(parent_key) # Use parent_key as the title for this group
            
            sorted_keys = sorted(data.keys(), key=lambda k: str(k))
            has_complex_child = False
            for key in sorted_keys:
                value = data[key]
                formatted_key = str(key).replace('_', ' ').title()

                if isinstance(value, (dict, list)) and value: # If value is complex and non-empty
                    has_complex_child = True
                    # If group_for_dict has items already, add it before processing complex child
                    if group_for_dict.get_first_child() and group_for_dict.get_parent() is None:
                        self.content_box.append(group_for_dict)
                        group_for_dict = self._create_property_group(parent_key) # Reset for next simple items if any

                    # Recursively process this complex value, using its key as the new parent_key/title
                    self._process_category_data(value, formatted_key, level + 1)
                else: # Simple value: add as a row to the current group_for_dict
                    val_str = str(value) if value is not None else "N/A"
                    if isinstance(value, dict) and 'value' in value and 'unit' in value: # Common inxi pattern
                        val_str = f"{value['value']} {value['unit']}"
                    self._add_property_to_group(group_for_dict, formatted_key, val_str)
            
            if group_for_dict.get_first_child() and group_for_dict.get_parent() is None: # Add the group if it has items and not already added
                self.content_box.append(group_for_dict)
            elif not group_for_dict.get_first_child() and not has_complex_child and parent_key: # Empty dict, but show title
                if group_for_dict.get_parent() is None: self.content_box.append(group_for_dict)


        else: # Simple value not in a dict/list (e.g. top-level string, unlikely for inxi)
            group = self._create_property_group(parent_key if parent_key else "Value")
            self._add_property_to_group(group, parent_key if parent_key else "Value", str(data) if data is not None else "N/A")
            if group.get_first_child(): self.content_box.append(group)
    
    def _create_property_group(self, title: str = "") -> Adw.PreferencesGroup:
        group = Adw.PreferencesGroup()
        if title:
            group.set_title(self._format_category_name(title)) 
        return group
    
    def _add_property_to_group(self, group: Adw.PreferencesGroup, key: str, value: str) -> None:
        row_title = str(key).strip()
        row_subtitle = str(value).strip()
        if not row_title and not row_subtitle: return 

        row = Adw.ActionRow()
        if not row_subtitle and not row_title.startswith(group.get_title() or "Item"):
            row.set_title(row_title)
            row.set_title_selectable(True)
        else:
            row.set_title(row_title)
            if row_subtitle:
                row.set_subtitle(row_subtitle)
                row.set_subtitle_lines(0) 
                row.set_subtitle_selectable(True)
            else: 
                row.set_title_selectable(True)
        row.set_activatable(False) 
        group.add(row)
    
    def _show_error_message(self, message: str) -> None:
        # ... (implementation from your previous version is fine) ...
        if self.pulse_id > 0: GLib.source_remove(self.pulse_id); self.pulse_id = 0
        self.progress_bar.set_fraction(0.0); self.progress_bar.set_visible(False)
        if self.split_view.get_visible():
            self.split_view.set_visible(False)
            while child := self.content_box.get_first_child(): self.content_box.remove(child)
            while child := self.category_list.get_first_child(): self.category_list.remove(child)
        if hasattr(self, 'error_box_container') and self.error_box_container.get_parent(): self.remove(self.error_box_container)
        self.error_box_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, vexpand=True, hexpand=True)
        self.error_box_container.set_halign(Gtk.Align.CENTER); self.error_box_container.set_valign(Gtk.Align.CENTER)
        error_box_content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        error_box_content.set_margin_top(24); error_box_content.set_margin_bottom(24); error_box_content.set_margin_start(24); error_box_content.set_margin_end(24)
        error_box_content.set_halign(Gtk.Align.CENTER)
        error_icon = Gtk.Image.new_from_icon_name("dialog-error-symbolic"); error_icon.set_pixel_size(64); error_box_content.append(error_icon)
        error_label = Gtk.Label(label=message); error_label.set_wrap(True); error_label.set_max_width_chars(60)
        error_label.set_justify(Gtk.Justification.CENTER); error_label.add_css_class("title-3"); error_box_content.append(error_label)
        retry_button = Gtk.Button(label="Tentar Novamente"); retry_button.connect("clicked", self._on_refresh_clicked) 
        retry_button.set_halign(Gtk.Align.CENTER); retry_button.add_css_class("pill"); retry_button.add_css_class("suggested-action")
        error_box_content.append(retry_button); self.error_box_container.append(error_box_content); self.append(self.error_box_container)
    
    def _on_refresh_clicked(self, button: Optional[Gtk.Button]=None) -> None:
        if hasattr(self, 'error_box_container') and self.error_box_container.get_parent():
            self.remove(self.error_box_container)
        while child := self.content_box.get_first_child(): self.content_box.remove(child)
        while child := self.category_list.get_first_child(): self.category_list.remove(child)
        self.hardware_data = {}; self.raw_inxi_data = {}
        self._load_hardware_info()

# Example usage
if __name__ == '__main__':
    # Create a dummy hardware.json for testing if not present
    dummy_json_content = """
    [
      {"System": [{"Kernel": "6.1.0-test", "Distro": "TestOS Linux"}]},
      {"CPU": [{"model": "Test CPU Ultra"}, {"cores": 4, "threads": 8}]},
      {"Info": [{"Memory": "", "total": "8 GiB", "used": "2.5 GiB (31.2%)", "available": "5.5 GiB"}]},
      {"Graphics": [{"class-ID": "0300", "vendor": "TestGPU Inc.", "Device": "Spectra 9000"}]},
      {"Partition": [
          {"ID": "/boot/efi", "dev": "/dev/sda1", "raw-size": "500MiB", "used": "50MiB (10%)"},
          {"ID": "/", "dev": "/dev/sda2", "raw-size": "100GiB", "used": "60GiB (60%)"}
      ]}
    ]
    """
    # You would typically run `inxi ... > hardware.json` to get a real file.
    # For this test, if 'hardware.json' from the prompt isn't in the same dir, it will use this dummy.
    json_file_path = "hardware.json" 
    if not os.path.exists(json_file_path):
        print(f"'{json_file_path}' not found. Using dummy data for testing System Overview.")
        # Instead of writing a file, let's simulate the _fetch_inxi_data part for the dummy.
        # This requires temporarily overriding _fetch_inxi_data for the test.
        original_fetch = HardwareInfoPage._fetch_inxi_data
        def mock_fetch_inxi_data(self_page):
            try:
                logger.info("Using MOCK inxi data for System Overview test.")
                raw_data_list_from_json = json.loads(dummy_json_content)
                transformed_data: Dict[str, List[Dict[str, Any]]] = {}
                if isinstance(raw_data_list_from_json, list):
                    for item_dict_wrapper in raw_data_list_from_json:
                        if isinstance(item_dict_wrapper, dict):
                            transformed_data.update(item_dict_wrapper)
                self_page.raw_inxi_data = transformed_data
                self_page.hardware_data = self_page._map_raw_to_display_categories(self_page.raw_inxi_data)
                GLib.idle_add(self_page._update_ui_with_data)
            except Exception as e:
                logger.error(f"Error in mock_fetch_inxi_data: {e}")
                GLib.idle_add(self_page._show_error_message, f"Mock data error: {str(e)}")

        HardwareInfoPage._fetch_inxi_data = mock_fetch_inxi_data


    class MainWindow(Gtk.ApplicationWindow):
        def __init__(self, app):
            super().__init__(application=app, title="Hardware Info Test")
            self.set_default_size(850, 750)
            page = HardwareInfoPage()
            self.set_child(page)

    class TestApp(Adw.Application):
        def __init__(self):
            super().__init__(application_id="com.example.hardwareinfotest")
        def do_activate(self):
            win = MainWindow(self)
            win.present()

    app = TestApp()
    app.run(None)

    # Restore original fetch if mocked
    if 'original_fetch' in globals():
        HardwareInfoPage._fetch_inxi_data = original_fetch