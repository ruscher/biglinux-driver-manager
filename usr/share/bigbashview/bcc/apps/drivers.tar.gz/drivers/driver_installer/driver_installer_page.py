"""
Driver Installer Page - Enhanced Version

This module provides an enhanced driver installer page for the BigLinux Driver Manager
with better error handling, threading, and UI feedback.
"""
import gi
import logging
import subprocess
import json
import os
import threading
import shutil
from typing import Dict, List, Any, Optional
from concurrent.futures import ThreadPoolExecutor, TimeoutError

# Import our driver lister module
from driver_installer.driver_lister import list_all_drivers

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, GLib, Gio, GObject, Pango

# Constants
DEFAULT_MARGINS = 16
LOADING_TIMEOUT = 30  # seconds
OPERATION_TIMEOUT = 300  # 5 minutes for package operations
HARDWARE_DETECTION_COMMANDS = {
    'cpu': 'lscpu',
    'gpu': 'lspci | grep -i "VGA\\|3D"',
    'network': 'lspci | grep -i "Network\\|Ethernet"',
    'sound': 'lspci | grep -i "Audio"'
}

# Set up logger
logger = logging.getLogger(__name__)

class DriverInstallerPage(Gtk.Box):
    """
    Enhanced Driver Installer page component.
    
    Features:
    - Better hardware detection with caching
    - Improved threading and error handling
    - Enhanced UI feedback
    - Operation timeouts
    """
    
    def __init__(self) -> None:
        """Initialize the enhanced driver installer page."""
        super().__init__(
            orientation=Gtk.Orientation.VERTICAL, 
            spacing=12,
            margin_top=DEFAULT_MARGINS,
            margin_bottom=DEFAULT_MARGINS,
            margin_start=DEFAULT_MARGINS,
            margin_end=DEFAULT_MARGINS
        )
        
        self._initialize_properties()
        self._check_dependencies()
        self._create_ui()
        self._load_drivers()
    
    def _initialize_properties(self):
        """Initialize all class properties."""
        self.preferences_page = None
        self.driver_groups = []
        self.loading_spinner = None
        self.show_only_compatible = True
        self.hardware_info = {}
        self._operation_lock = threading.Lock()
    
    def _check_dependencies(self) -> bool:
        """Check for required system dependencies."""
        required = ["lspci", "lscpu", "pkexec"]
        missing = []
        
        for cmd in required:
            if not shutil.which(cmd):
                missing.append(cmd)
        
        if missing:
            self._show_error_dialog(
                "Dependências ausentes",
                f"Os seguintes comandos são necessários mas não foram encontrados:\n{', '.join(missing)}"
            )
            return False
        return True
    
    def _create_ui(self) -> None:
        """Create the enhanced UI components."""
        # Header Section
        self._create_header()
        
        # Hardware Summary
        self._create_hardware_summary()
        
        # Main Content Area
        self._create_main_content()
        
        # Loading Indicator
        self._create_loading_indicator()
    
    def _create_header(self):
        """Create the header section."""
        header = Adw.HeaderBar()
        header.set_title_widget(Gtk.Label(label="Instalador de Drivers"))
        
        # Filter toggle
        self.compatibility_switch = Gtk.Switch(
            active=self.show_only_compatible,
            tooltip_text="Mostrar apenas drivers compatíveis"
        )
        self.compatibility_switch.connect("state-set", self._on_compatibility_switch_changed)
        
        # Refresh button
        refresh_btn = Gtk.Button(
            icon_name="view-refresh-symbolic",
            tooltip_text="Recarregar lista de drivers"
        )
        refresh_btn.connect("clicked", self._on_refresh_clicked)
        
        header.pack_end(refresh_btn)
        header.pack_end(self.compatibility_switch)
        
        self.append(header)
    
    def _create_hardware_summary(self):
        """Create hardware summary section."""
        self.hardware_summary = Adw.PreferencesGroup()
        self.hardware_summary.set_title("Hardware Detectado")
        self.hardware_summary.set_margin_bottom(16)
        self.append(self.hardware_summary)
    
    def _create_main_content(self):
        """Create main content area."""
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scrolled_window.set_vexpand(True)
        
        clamp = Adw.Clamp()
        self.preferences_page = Adw.PreferencesPage()
        clamp.set_child(self.preferences_page)
        scrolled_window.set_child(clamp)
        
        self.append(scrolled_window)
    
    def _create_loading_indicator(self):
        """Create loading indicator."""
        self.loading_spinner = Gtk.Spinner()
        self.loading_spinner.set_size_request(32, 32)
        self.loading_spinner.set_halign(Gtk.Align.CENTER)
        self.loading_spinner.set_valign(Gtk.Align.CENTER)
        self.loading_spinner.set_vexpand(True)
    
    def _load_drivers(self) -> None:
        """Initiate the driver loading process."""
        if not self._get_cached_hardware_info():
            self._show_loading()
        
        GLib.idle_add(self._load_and_populate_drivers)
    
    def _show_loading(self) -> None:
        """Show the loading spinner."""
        self._clear_driver_list_ui()
        
        if self.loading_spinner.get_parent():
            self.loading_spinner.get_parent().remove(self.loading_spinner)
        
        self.append(self.loading_spinner)
        self.loading_spinner.start()
    
    def _hide_loading(self) -> None:
        """Hide the loading spinner."""
        if self.loading_spinner.get_parent():
            self.loading_spinner.stop()
            self.loading_spinner.get_parent().remove(self.loading_spinner)
    
    def _on_refresh_clicked(self, button: Gtk.Button) -> None:
        """Handle refresh button click."""
        logger.info("Manual refresh requested")
        self._load_drivers()
    
    def _on_compatibility_switch_changed(self, switch: Gtk.Switch, state: bool) -> bool:
        """Handle compatibility switch state change."""
        self.show_only_compatible = state
        logger.info(f"Compatibility filter set to: {state}")
        self._load_drivers()
        return False
    
    def _get_cached_hardware_info(self) -> bool:
        """Try to load hardware info from cache."""
        cache_file = os.path.expanduser("~/.cache/biglinux-drivers/hardware.json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file) as f:
                    self.hardware_info = json.load(f)
                    return True
            except Exception:
                return False
        return False
    
    def _cache_hardware_info(self):
        """Cache hardware info for faster loading."""
        cache_dir = os.path.expanduser("~/.cache/biglinux-drivers")
        os.makedirs(cache_dir, exist_ok=True)
        
        try:
            with open(os.path.join(cache_dir, "hardware.json"), "w") as f:
                json.dump(self.hardware_info, f)
        except Exception as e:
            logger.error(f"Could not cache hardware info: {e}")
    
    def _detect_hardware(self) -> None:
        """Detect hardware components with better error handling."""
        hardware_info = {}
        
        with ThreadPoolExecutor() as executor:
            futures = {
                'cpu': executor.submit(self._get_hardware_info, 'cpu'),
                'gpu': executor.submit(self._get_hardware_info, 'gpu'),
                'network': executor.submit(self._get_hardware_info, 'network'),
                'sound': executor.submit(self._get_hardware_info, 'sound')
            }
            
            for hw_type, future in futures.items():
                try:
                    result = future.result(timeout=10)
                    if result:
                        hardware_info[hw_type] = result
                except Exception as e:
                    logger.error(f"Error detecting {hw_type}: {e}", exc_info=True)
        
        self.hardware_info = hardware_info
        self._cache_hardware_info()
        logger.info(f"Detected hardware: {list(hardware_info.keys())}")
    
    def _get_hardware_info(self, hw_type: str) -> Any:
        """Generic hardware info fetcher."""
        try:
            result = subprocess.run(
                HARDWARE_DETECTION_COMMANDS[hw_type],
                shell=True,
                capture_output=True,
                text=True,
                check=False
            )
            
            if result.returncode != 0:
                return [] if hw_type in ['gpu', 'network', 'sound'] else {}
            
            return getattr(self, f"_parse_{hw_type}_info")(result.stdout)
        except Exception as e:
            logger.error(f"Error getting {hw_type} info: {e}")
            return [] if hw_type in ['gpu', 'network', 'sound'] else {}
    
    def _parse_cpu_info(self, output: str) -> Dict[str, str]:
        """Parse CPU information from lscpu output."""
        info = {}
        for line in output.splitlines():
            if "Model name" in line:
                info['model'] = line.split(':', 1)[1].strip()
            elif "Architecture" in line:
                info['architecture'] = line.split(':', 1)[1].strip()
            elif "CPU(s)" in line and "NUMA" not in line:
                info['cores'] = line.split(':', 1)[1].strip()
        return info
    
    def _parse_gpu_info(self, output: str) -> List[Dict[str, str]]:
        """Parse GPU information from lspci output."""
        gpus = []
        for line in output.splitlines():
            gpu = {'device': line.split(':', 1)[1].strip()}
            
            if "NVIDIA" in line:
                gpu['vendor'] = "NVIDIA"
            elif "AMD" in line or "ATI" in line:
                gpu['vendor'] = "AMD"
            elif "Intel" in line:
                gpu['vendor'] = "Intel"
            else:
                gpu['vendor'] = "Unknown"
            
            gpus.append(gpu)
        return gpus
    
    def _parse_network_info(self, output: str) -> List[Dict[str, str]]:
        """Parse network device information."""
        network_devices = []
        for line in output.splitlines():
            device_type = "WiFi" if "Network controller" in line else "Ethernet"
            device = {
                'type': device_type,
                'device': line.split(':', 1)[1].strip()
            }
            network_devices.append(device)
        return network_devices
    
    def _parse_sound_info(self, output: str) -> List[Dict[str, str]]:
        """Parse sound device information."""
        sound_devices = []
        for line in output.splitlines():
            device = {'device': line.split(':', 1)[1].strip()}
            sound_devices.append(device)
        return sound_devices
    
    def _update_hardware_summary(self) -> None:
        """Update the hardware summary UI with detected hardware."""
        # Clear existing rows
        child = self.hardware_summary.get_first_child()
        while child is not None:
            next_child = child.get_next_sibling()
            self.hardware_summary.remove(child)
            child = next_child
            
        # If no hardware detected, show a message
        if not self.hardware_info:
            row = Adw.ActionRow()
            row.set_title("Nenhum hardware detectado")
            row.set_subtitle("Não foi possível detectar o hardware do sistema")
            self.hardware_summary.add(row)
            return
        
        # Add CPU info
        if 'cpu' in self.hardware_info:
            cpu = self.hardware_info['cpu']
            if 'model' in cpu:
                row = Adw.ActionRow()
                row.set_title("CPU")
                row.set_subtitle(f"{cpu.get('model', 'Unknown')} ({cpu.get('cores', '?')} cores)")
                self.hardware_summary.add(row)
        
        # Add GPU info
        if 'gpu' in self.hardware_info and self.hardware_info['gpu']:
            for i, gpu in enumerate(self.hardware_info['gpu']):
                row = Adw.ActionRow()
                row.set_title(f"GPU {i+1}")
                row.set_subtitle(f"{gpu.get('vendor', 'Unknown')}: {gpu.get('device', 'Unknown')}")
                self.hardware_summary.add(row)
        
        # Add Network info
        if 'network' in self.hardware_info and self.hardware_info['network']:
            for i, net in enumerate(self.hardware_info['network']):
                row = Adw.ActionRow()
                row.set_title(f"{net.get('type', 'Network')} {i+1}")
                row.set_subtitle(net.get('device', 'Unknown'))
                self.hardware_summary.add(row)
        
        # Add Sound info
        if 'sound' in self.hardware_info and self.hardware_info['sound']:
            for i, sound in enumerate(self.hardware_info['sound']):
                row = Adw.ActionRow()
                row.set_title(f"Áudio {i+1}")
                row.set_subtitle(sound.get('device', 'Unknown'))
                self.hardware_summary.add(row)
    
    def _fetch_drivers_data(self) -> Optional[List[Dict[str, Any]]]:
        """Fetch driver data with better thread management."""
        try:
            if not self._get_cached_hardware_info():
                self._detect_hardware()
            
            drivers_data = None
            
            with ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(self._fetch_drivers_thread)
                try:
                    drivers_data = future.result(timeout=LOADING_TIMEOUT)
                except TimeoutError:
                    logger.error("Driver listing operation timed out")
                    future.cancel()
                    return None
                    
            return drivers_data
        except Exception as e:
            logger.error(f"Unexpected error while fetching driver data: {e}", exc_info=True)
            return None
    
    def _fetch_drivers_thread(self) -> Optional[List[Dict[str, Any]]]:
        """Thread worker for fetching drivers."""
        try:
            all_drivers = list_all_drivers()
            return [
                d for d in all_drivers 
                if not self.show_only_compatible or d.get('compatible', False)
            ]
        except Exception as e:
            logger.error(f"Error in list_all_drivers: {e}", exc_info=True)
            return None
    
    def _load_and_populate_drivers(self) -> bool:
        """Load driver data and populate the preferences page."""
        drivers_data = self._fetch_drivers_data()
        self._hide_loading()
        
        # Update hardware summary
        self._update_hardware_summary()
        
        if drivers_data is None:
            self._show_error_message(
                "Erro ao buscar drivers", 
                "Não foi possível obter a lista de drivers. Verifique os logs para mais detalhes."
            )
            return False
        
        if not drivers_data:
            self._show_message(
                "Nenhum driver encontrado", 
                "Não foram encontrados drivers disponíveis para seu hardware.",
                "emblem-info-symbolic"
            )
            return False
        
        # Group drivers by category
        grouped_drivers: Dict[str, List[Dict[str, Any]]] = {}
        for driver in drivers_data:
            category_label = driver.get('category_label', 'Outros')
            if category_label not in grouped_drivers:
                grouped_drivers[category_label] = []
            grouped_drivers[category_label].append(driver)
        
        # Create a group for each category
        for category_label, drivers_in_category in sorted(grouped_drivers.items()):
            if not drivers_in_category:
                continue
                
            group = Adw.PreferencesGroup()
            group.set_title(category_label)
            self.preferences_page.add(group)
            self.driver_groups.append(group)
            
            # Add each driver as an action row
            for driver in sorted(drivers_in_category, key=lambda d: d.get('name', '')):
                self._add_driver_row(group, driver)
        
        return False
    
    def _add_driver_row(self, group: Adw.PreferencesGroup, driver: Dict[str, Any]) -> None:
        """Add a driver row to the specified group."""
        row = Adw.ActionRow()
        row.set_title(driver.get('name', 'Driver desconhecido'))
        
        # Set description with wrapping
        description = driver.get('description', 'Sem descrição disponível.')
        subtitle_label = Gtk.Label(label=description)
        subtitle_label.set_ellipsize(Pango.EllipsizeMode.END)
        subtitle_label.set_lines(2)
        subtitle_label.set_wrap(True)
        subtitle_label.set_wrap_mode(Pango.WrapMode.WORD_CHAR)
        subtitle_label.set_xalign(0)
        row.set_subtitle(description)
        
        # Add status indicators and action buttons
        status_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        
        is_installed = driver.get('installed', False)
        is_loaded = driver.get('loaded', False)
        is_compatible = driver.get('compatible', False)
        source_type = driver.get('source', '')
        
        # Add compatibility icon
        if is_compatible:
            compat_icon = Gtk.Image.new_from_icon_name("emblem-default")
            compat_icon.set_tooltip_text("Compatível com seu hardware")
            status_box.append(compat_icon)
        
        # Show "Em uso" label for loaded drivers
        if is_installed and is_loaded and source_type == 'device-ids':
            status_label = Gtk.Label()
            status_label.set_markup("<span style='italic' size='small'>Em uso</span>")
            status_label.add_css_class("success")
            status_box.append(status_label)
        
        # Create appropriate button based on installation status
        if is_installed:
            button = Gtk.Button(label="Desinstalar")
            button.add_css_class("destructive-action")
            button.connect("clicked", self._on_uninstall_clicked, driver)
        else:
            button = Gtk.Button(label="Instalar")
            button.add_css_class("suggested-action")
            button.connect("clicked", self._on_install_clicked, driver)
        
        status_box.append(button)
        row.add_suffix(status_box)
        group.add(row)
    
    def _show_message(self, title: str, description: Optional[str] = None, 
                     icon_name: str = "dialog-information-symbolic") -> None:
        """Show a message on the page."""
        self._clear_driver_list_ui()
        
        group = Adw.PreferencesGroup()
        self.preferences_page.add(group)
        self.driver_groups.append(group)
        
        status_page = Adw.StatusPage()
        status_page.set_title(title)
        if description:
            status_page.set_description(description)
        status_page.set_icon_name(icon_name)
        status_page.set_vexpand(True)
        
        group.add(status_page)
    
    def _show_error_message(self, title: str, description: Optional[str] = None) -> None:
        """Show an error message on the page."""
        self._show_message(title, description, "dialog-error-symbolic")
    
    def _show_error_dialog(self, title: str, message: str) -> None:
        """Show a standardized error dialog."""
        dialog = Adw.MessageDialog(
            transient_for=self.get_root(),
            heading=title,
            body=message,
            close_response="ok"
        )
        dialog.add_response("ok", "OK")
        dialog.present()
    
    def _clear_driver_list_ui(self) -> None:
        """Clear all driver groups from the UI."""
        groups_to_remove = []
        for group in self.driver_groups:
            if group.get_parent() == self.preferences_page:
                groups_to_remove.append(group)
        
        for group in groups_to_remove:
            self.preferences_page.remove(group)
            
        self.driver_groups.clear()
    
    def _on_install_clicked(self, button: Gtk.Button, driver_info: Dict[str, Any]) -> None:
        """Handle install button click."""
        pkg_name = driver_info.get('package', driver_info.get('name', 'unknown'))
        logger.info(f"Install requested for: {pkg_name}")
        
        dialog = Adw.MessageDialog.new(
            self.get_root(),
            f"Instalar {pkg_name}?",
            f"Isso instalará o driver '{pkg_name}' no seu sistema.\n\nEste processo requer privilégios de administrador."
        )
        
        dialog.add_response("cancel", "Cancelar")
        dialog.add_response("install", "Instalar")
        dialog.set_response_appearance("install", Adw.ResponseAppearance.SUGGESTED)
        dialog.set_default_response("install")
        dialog.connect("response", self._on_install_dialog_response, pkg_name)
        dialog.present()
    
    def _on_install_dialog_response(self, dialog: Adw.MessageDialog, response: str, pkg_name: str) -> None:
        """Handle install dialog response with better flow."""
        dialog.destroy()
        
        if response != "install":
            return
        
        self._show_loading()
        
        def install_thread():
            try:
                success = self._install_package(pkg_name)
                GLib.idle_add(
                    self._update_ui_after_operation, 
                    success, 
                    pkg_name, 
                    "install"
                )
            except Exception as e:
                logger.error(f"Installation thread error: {e}")
                GLib.idle_add(
                    self._handle_operation_error,
                    "instalação",
                    pkg_name,
                    str(e)
                )
                GLib.idle_add(self._hide_loading)
        
        threading.Thread(target=install_thread, daemon=True).start()
    
    def _install_package(self, pkg_name: str) -> bool:
        """Install a package with proper error handling."""
        try:
            result = subprocess.run(
                ["pkexec", "pacman", "-S", "--noconfirm", pkg_name],
                capture_output=True,
                text=True,
                check=True,
                timeout=OPERATION_TIMEOUT
            )
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            logger.error(f"Timeout installing {pkg_name}")
            return False
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to install {pkg_name}: {e.stderr}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error installing {pkg_name}: {e}")
            return False
    
    def _on_uninstall_clicked(self, button: Gtk.Button, driver_info: Dict[str, Any]) -> None:
        """Handle uninstall button click."""
        pkg_name = driver_info.get('package', driver_info.get('name', 'unknown'))
        logger.info(f"Uninstall requested for: {pkg_name}")
        
        dialog = Adw.MessageDialog.new(
            self.get_root(),
            f"Desinstalar {pkg_name}?",
            f"Isso removerá o driver '{pkg_name}' do seu sistema.\n\nEste processo requer privilégios de administrador."
        )
        
        dialog.add_response("cancel", "Cancelar")
        dialog.add_response("uninstall", "Desinstalar")
        dialog.set_response_appearance("uninstall", Adw.ResponseAppearance.DESTRUCTIVE)
        dialog.set_default_response("cancel")
        dialog.connect("response", self._on_uninstall_dialog_response, pkg_name)
        dialog.present()
    
    def _on_uninstall_dialog_response(self, dialog: Adw.MessageDialog, response: str, pkg_name: str) -> None:
        """Handle uninstall dialog response."""
        dialog.destroy()
        
        if response != "uninstall":
            return
        
        self._show_loading()
        
        def uninstall_thread():
            try:
                success = self._uninstall_package(pkg_name)
                GLib.idle_add(
                    self._update_ui_after_operation, 
                    success, 
                    pkg_name, 
                    "uninstall"
                )
            except Exception as e:
                logger.error(f"Uninstallation thread error: {e}")
                GLib.idle_add(
                    self._handle_operation_error,
                    "desinstalação",
                    pkg_name,
                    str(e)
                )
                GLib.idle_add(self._hide_loading)
        
        threading.Thread(target=uninstall_thread, daemon=True).start()
    
    def _uninstall_package(self, pkg_name: str) -> bool:
        """Uninstall a package with proper error handling."""
        try:
            result = subprocess.run(
                ["pkexec", "pacman", "-Rns", "--noconfirm", pkg_name],
                capture_output=True,
                text=True,
                check=True,
                timeout=OPERATION_TIMEOUT
            )
            return result.returncode == 0
        except subprocess.TimeoutExpired:
            logger.error(f"Timeout uninstalling {pkg_name}")
            return False
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to uninstall {pkg_name}: {e.stderr}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error uninstalling {pkg_name}: {e}")
            return False
    
    def _update_ui_after_operation(self, success: bool, pkg_name: str, operation: str) -> None:
        """Update UI after package operation."""
        self._hide_loading()
        
        if success:
            logger.info(f"Successfully {operation}ed {pkg_name}")
            toast = Adw.Toast(
                title=f"{pkg_name} {operation}ado com sucesso",
                timeout=3
            )
            self.get_root().add_toast(toast)
        else:
            self._show_error_dialog(
                f"Falha ao {operation}",
                f"Não foi possível {operation} o pacote {pkg_name}"
            )
        
        self._load_drivers()
    
    def _handle_operation_error(self, operation: str, pkg_name: str, error: str) -> None:
        """Standardized error handling for package operations."""
        logger.error(f"{operation} error for {pkg_name}: {error}")
        GLib.idle_add(
            self._show_error_dialog,
            f"Erro ao {operation} {pkg_name}",
            f"Ocorreu um erro durante a operação:\n\n{error}"
        )